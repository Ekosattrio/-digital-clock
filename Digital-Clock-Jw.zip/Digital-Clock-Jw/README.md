# Simple Digital Clock with JavaScript
